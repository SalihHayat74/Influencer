



class FirestoreConstants{
  static const String userCollection="User Collection";



}